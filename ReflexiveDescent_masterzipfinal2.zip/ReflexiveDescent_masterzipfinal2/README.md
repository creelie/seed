# Reflexive Descent to Minimal Seeds in the Kreuzer–Skarke List

Deep Bhattacharjee and Ushashi Bhattacharya

- `ReflexiveDescent_final2.pdf`: the paper (13 pages).
- `ReflexiveDescent_final2-tex.zip`: its LaTeX source with the figures as PNG. It compiles with
  plain `pdflatex` (REVTeX 4.2, TeX Live 2026), with no BibTeX pass and no shell escape.
- `ReflexiveDescent-v1.0.1-arxiv.tar.gz`: the arXiv package, with the checks, the data and the
  Lean file in `anc/`.
- `seed-v1.0.1/`: the repository creelie/seed at release 1.0.1: the paper, the data, the
  certificate of depth 22, the 77 independent checks in C, C++, Python, Julia, Macaulay2 and
  shell (`code/run_checks.sh`), the 24 Lean 4 theorems (`lean/Seed.lean`), the certification
  programs (`code/certify/`) and the engine record (`code/bllm/`).

Proved: every reflexive polytope descends to a minimal seed one cover at a time; the largest
transition depths are 5 in dimension two and 11 in dimension three; in dimension four
22 ≤ D_4 ≤ 348, with two 37-point polytopes of depth exactly 22 and the 680-point polytope of
depth at most 31. The exact value of D_4 is open.

The archive is on Zenodo: release 1.0.1 under doi:10.5281/zenodo.23483443, all versions under
doi:10.5281/zenodo.23483239. The Anaxia engine used for the constructions is creelie/eBLLM,
release 3.0.5, doi:10.5281/zenodo.23469389.
